package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.ReplyVO;
import com.example.mapper.BoardDAO;
import com.example.mapper.ReplyDAO;

@Service
public class ReplyServiceImpl implements ReplyService{
	
	@Autowired
	ReplyDAO rdao;
	
	@Autowired
	BoardDAO bdao;
	
	@Transactional
	@Override
	public void insert(ReplyVO vo) {
		rdao.insert(vo);
		bdao.updatereply(vo.getBno(), 1);
	}

	@Transactional
	@Override
	public void delete(int rno) {
		ReplyVO vo = rdao.read(rno);
		bdao.updatereply(vo.getBno(), -1);
		rdao.delete(rno);
	}

}
