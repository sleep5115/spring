package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.BoardVO;
import com.example.domain.ReplyVO;
import com.example.mapper.BoardDAO;
import com.example.mapper.ReplyDAO;
import com.example.service.ReplyService;

@RestController
@RequestMapping("/reply")
public class ReplyController {
	@Autowired
	ReplyDAO dao;
	
	@Autowired
	ReplyService service;
	
	@RequestMapping("/list.json")
	public List<ReplyVO> list(int bno) {
		return dao.list(bno);
	}
	
	@Autowired
	BoardDAO bdao;
	
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public int insert(ReplyVO vo){
		service.insert(vo);
		BoardVO bvo = bdao.read(vo.getBno());
		return bvo.getReplycount();
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public int delete(int rno){
		ReplyVO vo = dao.read(rno);
		service.delete(rno);
		BoardVO bvo = bdao.read(vo.getBno());
		return bvo.getReplycount();
	}
}
