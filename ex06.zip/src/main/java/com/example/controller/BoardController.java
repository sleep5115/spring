package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.BoardVO;
import com.example.mapper.BoardDAO;
import com.example.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	BoardDAO dao;
	
	@Autowired
	BoardService service;
	
	@RequestMapping("/insert")
	public void insert() {
		
	}
	
	@RequestMapping("/getAttach")
	@ResponseBody
	public List<String> getAttach(int bno) {
		return dao.getAttach(bno);
	}
	
	@RequestMapping("/read")
	public String read(int bno, Model model) {
		model.addAttribute("vo", dao.read(bno));
		return "read";
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insertPost(BoardVO vo) {
		System.out.println(vo.toString());
		service.insert(vo);
		return "redirect:list";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updatePost(BoardVO vo) {
		System.out.println(vo.toString());
		service.update(vo);
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String list(Model model){
		model.addAttribute("list", dao.list());
		return "list";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String deletePost(int bno) {
		System.out.println(bno);
		service.delete(bno);
		return "redirect:list";
	}
}
