package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.BoardVO;
import com.example.mapper.BoardDAO;

@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	BoardDAO dao;
	
	@Transactional
	@Override
	public void insert(BoardVO vo) {
		// �Խñ� ���
		dao.insert(vo);;
		// ÷������ ���
		String[] files = vo.getFiles();
		if(files == null) return;
		for(String fullName : files) {
			dao.addAttach(fullName);
		}
		
		dao.newattachcount();
	}
	
	@Transactional
	@Override
	public void update(BoardVO vo) {
		dao.update(vo);
		
		// ���� ÷������ ����
		int bno = vo.getBno();
		dao.deleteAttach(bno);
		
		// ÷������ ���
		String[] files = vo.getFiles();
		
		if (files != null) {
			for (String fullName : files) {
				dao.replaceAttach(bno, fullName);
			}
		}
		
		dao.attachcount(bno);
	}
	
	@Transactional
	@Override
	public void delete(int bno) {
		dao.deleteAttach(bno);
		dao.delete(bno);
	}
}
