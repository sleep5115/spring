package com.example.mapper;

import java.util.List;

import com.example.domain.BoardVO;

public interface BoardDAO {
	public List<BoardVO> list();
	public void insert(BoardVO vo);
	public void update(BoardVO vo);
	public void delete(int bno);
	public BoardVO read(int bno);
	public void addAttach(String fullName);
	public List<String> getAttach(int bno);
	public void replaceAttach(int bno, String fullName);
	public void deleteAttach(int bno);
	public void attachcount(int bno);
	public void newattachcount();
}
