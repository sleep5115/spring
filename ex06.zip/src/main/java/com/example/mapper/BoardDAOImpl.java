package com.example.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.BoardVO;

@Repository
public class BoardDAOImpl implements BoardDAO{
	@Autowired
	SqlSession session;
	
	String namespace = "com.example.mapper.BoardMapper";
	
	@Override
	public List<BoardVO> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public void insert(BoardVO vo) {
		session.insert(namespace + ".insert", vo);
	}

	@Override
	public void update(BoardVO vo) {
		session.update(namespace + ".update", vo);
	}

	@Override
	public void delete(int bno) {
		session.delete(namespace + ".delete", bno);
	}

	@Override
	public BoardVO read(int bno) {
		return session.selectOne(namespace + ".read", bno);
	}

	@Override
	public void addAttach(String fullName) {
		session.insert(namespace + ".addAttach", fullName);
	}

	@Override
	public List<String> getAttach(int bno) {
		return session.selectList(namespace + ".getAttach", bno);
	}

	@Override
	public void replaceAttach(int bno, String fullName) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("bno", bno);
		map.put("fullName", fullName);
		session.insert(namespace + ".replaceAttach", map);
	}

	@Override
	public void deleteAttach(int bno) {
		session.delete(namespace + ".deleteAttach", bno);
	}

	@Override
	public void attachcount(int bno) {
		session.update(namespace + ".attachcount", bno);
	}

	@Override
	public void newattachcount() {
		session.update(namespace + ".newattachcount");
	}
	
}
