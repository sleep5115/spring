package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.BoardVO;
import com.example.mapper.BoardMapper;
import com.example.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	BoardMapper mapper;
	
	@Autowired
	BoardService service;
	
	@RequestMapping("/list.json")
	@ResponseBody
	public List<BoardVO> list() {
		return mapper.list();
	}
	
	@RequestMapping("/list")
	public String getList(){
		return "list";
	}
	
	@RequestMapping("/read")
	public String getRead(int bno, Model model){
		model.addAttribute("vo", service.read(bno));
		return "read";
	}
}
