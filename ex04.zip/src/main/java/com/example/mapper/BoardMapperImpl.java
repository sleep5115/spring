package com.example.mapper;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.BoardVO;

@Repository
public class BoardMapperImpl implements BoardMapper{
	@Autowired
	SqlSession session;
	String namespace = "com.example.mapper.BoardMapper";
	
	@Override
	public List<BoardVO> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public BoardVO read(int bno) {
		return session.selectOne(namespace + ".read", bno);
	}

	@Override
	public void updateview(int bno) {
		session.update(namespace + ".updateview", bno);
	}
	
}
