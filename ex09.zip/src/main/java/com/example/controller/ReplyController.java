package com.example.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.domain.ReplyVO;
import com.example.mapper.ReplyDAO;

@RestController
public class ReplyController {
	@Autowired
	ReplyDAO rdao;
	
	@RequestMapping(value="/reply/delete", method=RequestMethod.POST)
	public void delete(int rno){
		rdao.delete(rno);
	}
	
	@RequestMapping(value="/reply/insert", method=RequestMethod.POST)
	public void insert(ReplyVO vo){
		rdao.insert(vo);
	}
	
	@RequestMapping("/reply.json")
	public HashMap<String, Object> list(int bno, Criteria cri){
		HashMap<String, Object> map = new HashMap<>();
		
		cri.setPerPageNum(3);
		map.put("list", rdao.list(bno, cri));
		
		PageMaker pm = new PageMaker();
		pm.setCri(cri);
		pm.setTotalCount(rdao.totalCount(bno));
		map.put("cri", cri);
		map.put("pm", pm);
		return map;
	}
}
