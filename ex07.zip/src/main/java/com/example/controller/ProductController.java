package com.example.controller;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.domain.ProductVO;
import com.example.mapper.AttachDAO;
import com.example.mapper.ProductDAO;
import com.example.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductDAO dao;
	
	@Autowired
	ProductService service;
	
	@Autowired
	AttachDAO adao;
	
	@Resource(name="uploadPath")
	private String path;
	
	//÷�������Է�
	@RequestMapping("/attInsert")
	@ResponseBody
	public void attInsert(String pcode, MultipartFile file){
		String image = pcode + "/" + System.currentTimeMillis() + "_" + file.getOriginalFilename();
		System.out.println(pcode);
	}
	
	//÷�����ϻ���
	@RequestMapping("/attDelete")
	@ResponseBody
	public void attDelete(String image){
		adao.delete(image);
		new File(path + "/" + image).delete();
	}
	
	@RequestMapping("/read")
	public String read(Model model, String pcode){
		model.addAttribute("attList", adao.list(pcode));
		model.addAttribute("vo", dao.read(pcode));
		model.addAttribute("pageName", "read.jsp");
		return "home";
	}
	
	@RequestMapping("/insert")
	public String insert(Model model) {
		String maxCode = dao.maxCode();
		String pcode = "P" + (Integer.parseInt(maxCode.substring(1)) + 1);
		model.addAttribute("pcode", pcode);
		model.addAttribute("pageName", "insert.jsp");
		return "home";
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insertPost(ProductVO vo, MultipartHttpServletRequest multi) throws Exception {
		MultipartFile file = multi.getFile("file");
		String image = System.currentTimeMillis() + "_" + file.getOriginalFilename();
		vo.setImage(image);
		//��ǥ ���� ���ε�
		file.transferTo(new File(path + "/" + image));
		
		//÷�����ϵ� ���ε�
		List<MultipartFile> files = multi.getFiles("files");
		ArrayList<String> images = new ArrayList<String>();
		for(MultipartFile attFile : files){
			if(!attFile.isEmpty()){
				String attImage = System.currentTimeMillis() + "_" + attFile.getOriginalFilename();
				images.add(vo.getPcode() + "/" + attImage);
				//����������
				File folder = new File(path + "/" + vo.getPcode());
				if(!folder.exists()) {
					folder.mkdir();
				}
				attFile.transferTo(new File(path + "/" + vo.getPcode() + "/" + attImage));
			}
		}
		vo.setImages(images);
		//System.out.println(vo.toString());
		
		//�������Է�
		service.insert(vo);
		return "redirect:/";
	}
	
	@RequestMapping("/list.json")
	@ResponseBody
	public List<ProductVO> listJson() {
		return dao.list();
	}
	
	// �̹������� �������� ���
	@RequestMapping("/display")
	@ResponseBody
	public ResponseEntity<byte[]> display(String fileName) throws Exception {
		ResponseEntity<byte[]> result = null;
		// display fileName�� �ִ� ���
		if (!fileName.equals("")) {
			File file = new File(path + File.separator + fileName);
			HttpHeaders header = new HttpHeaders();
			header.add("Content-Type", Files.probeContentType(file.toPath()));
			result = new ResponseEntity<>(FileCopyUtils.copyToByteArray(file), header, HttpStatus.OK);
		}
		return result;
	}
}
