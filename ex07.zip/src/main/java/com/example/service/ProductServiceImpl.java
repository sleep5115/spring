package com.example.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.ProductVO;
import com.example.mapper.AttachDAO;
import com.example.mapper.ProductDAO;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDAO pdao;
	
	@Autowired
	AttachDAO adao;
	
	@Transactional
	@Override
	public void insert(ProductVO vo) {
		pdao.insert(vo);
		
		ArrayList<String> images=vo.getImages();
		for(String image : images) {
			adao.insert(image, vo.getPcode());
		}
	}
}
