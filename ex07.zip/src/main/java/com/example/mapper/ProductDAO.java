package com.example.mapper;

import java.util.List;

import com.example.domain.ProductVO;

public interface ProductDAO {
	public List<ProductVO> list();
	public ProductVO read(String pcode);
	public void insert(ProductVO vo);
	public void update(ProductVO vo);
	public void delete(String pcode);
	public String maxCode();
}
