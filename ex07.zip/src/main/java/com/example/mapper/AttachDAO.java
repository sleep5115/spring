package com.example.mapper;

import java.util.List;

public interface AttachDAO {
	public void insert(String image, String pcode);
	public List<String> list(String pcode);
	public void delete(String image);
}
