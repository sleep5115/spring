package com.example.mapper;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.ProductVO;

@Repository
public class ProductDAOImpl implements ProductDAO {
	@Autowired
	SqlSession session;

	String namespace="com.example.mapper.ProductMapper";
	
	@Override
	public List<ProductVO> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public ProductVO read(String pcode) {
		return session.selectOne(namespace + ".read", pcode);
	}

	@Override
	public void insert(ProductVO vo) {
		session.insert(namespace + ".insert", vo);
	}

	@Override
	public void update(ProductVO vo) {
		session.update(namespace + ".update", vo);
	}

	@Override
	public void delete(String pcode) {
		session.delete(namespace + ".delete", pcode);
	}

	@Override
	public String maxCode() {
		return session.selectOne(namespace + ".maxCode");
	}
}
