package com.example.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.domain.ProductVO;
import com.example.mapper.AttachDAO;
import com.example.mapper.MysqlMapper;
import com.example.mapper.ProductDAO;

@RunWith(SpringJUnit4ClassRunner.class) //���� SpringJUnit4ClassRunner.class import�Ѵ�.
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
public class MysqlTest {
	@Autowired
	private AttachDAO dao;
	
	@Test
	public void maxCode() {
		dao.list("P122");
	}
	/*
	@Test
	public void list() {
		dao.list();
	}
	
	@Test
	public void read() {
		dao.read("P118");
	}
	*/
	/*
	@Test
	public void insert() {
		ProductVO vo = new ProductVO();
		vo.setPcode("P118");
		vo.setPname("�׽�Ʈ��ǰ");
		dao.insert(vo);
	}
	*/
	/*
	@Test
	public void update() {
		ProductVO vo = new ProductVO();
		vo.setPcode("P118");
		vo.setPname("�׽�Ʈ��ǰ ����");
		dao.insert(vo);
	}
	*/
	/*
	@Test
	public void delete() {
		dao.delete("P118");
	}
	*/
}
