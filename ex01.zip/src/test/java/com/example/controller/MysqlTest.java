package com.example.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.domain.BoardVO;
import com.example.mapper.BoardMapper;
import com.example.mapper.MysqlMapper;

@RunWith(SpringJUnit4ClassRunner.class) //���� SpringJUnit4ClassRunner.class import�Ѵ�.
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
public class MysqlTest {
	@Autowired
	private MysqlMapper mapper;
	
	@Autowired
	private BoardMapper bmapper;
	
	@Test
	public void delete() {
		bmapper.delete(4);
	}
	
	@Test
	public void read() {
		bmapper.read(3);
	}
	
	@Test
	public void update() {
		BoardVO vo = new BoardVO();
		vo.setTitle("������ �����Դϴ�.");
		vo.setContent("������ �����Դϴ�.");
		vo.setBno(6);
		bmapper.update(vo);
	}
	
	/*
	@Test
	public void insert() {
		BoardVO vo = new BoardVO();
		vo.setTitle("������ �Է��մϴ�.");
		vo.setContent("������ �Է��մϴ�.");
		vo.setWriter("user02");
		bmapper.insert(vo);
	}
	*/
	
	@Test
	public void getList() {
		bmapper.list();
	}

	@Test
	public void getTime() {
		mapper.getTime();
	}

}
