package com.example.service;

import com.example.domain.ProductVO;

public interface ProductService {
	public ProductVO read(String pcode);
}
