package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.ProductVO;
import com.example.mapper.ProductDAO;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAO pdao;
	
	@Transactional
	@Override
	public ProductVO read(String pcode) {
		pdao.viewcnt(pcode);
		return pdao.read(pcode);
	}

}
