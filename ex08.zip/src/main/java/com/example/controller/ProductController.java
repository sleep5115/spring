package com.example.controller;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.domain.ProductVO;
import com.example.mapper.AttachDAO;
import com.example.mapper.ProductDAO;
import com.example.service.ProductService;

@Controller
public class ProductController {
	
	@Resource(name="uploadPath")
	private String path;
	
	@Autowired
	ProductDAO pdao;
	
	@Autowired
	AttachDAO adao;
	
	@Autowired
	ProductService service;
	
	//����Ʈ��ǰ
	@RequestMapping("/best.json")
	@ResponseBody
	public List<HashMap<String, Object>> best(){
		return pdao.bestProduct();
	}
	
	//�ֽŻ�ǰ
	@RequestMapping("/new.json")
	@ResponseBody
	public List<HashMap<String, Object>> newProduct(){
		return pdao.newProduct();
	}
	
	//÷������ ����
	@RequestMapping(value="attDelete", method=RequestMethod.POST)
	@ResponseBody
	public void attDelete(String image) throws Exception {
		new File(path + "/" + image).delete();
		adao.delete(image);
	}
	
	//÷������ �߰�
	@RequestMapping(value="attInsert", method=RequestMethod.POST)
	@ResponseBody
	public String attInsert(String pcode, MultipartFile file) throws Exception{
		//÷������ ���ε�
		File attPath = new File(path + "/" + pcode);
		if(!attPath.exists()) attPath.mkdir();
		String image = pcode + "/" + System.currentTimeMillis() + "_" + file.getOriginalFilename();
		file.transferTo(new File(path + "/" + image));
		
		//÷�ε����� �Է�
		adao.insert(pcode, image);
		return image;
	}
	
	@RequestMapping(value="update", method=RequestMethod.POST)
	public String update(ProductVO vo, MultipartHttpServletRequest multi) throws Exception{
		MultipartFile file = multi.getFile("file");
		//�̹����� �ٲ���
		if(!file.isEmpty()){
			new File(path + "/" + vo.getImage()).delete();
			String image = System.currentTimeMillis() + "_" + file.getOriginalFilename();
			file.transferTo(new File(path + "/" + image));
			vo.setImage(image);
		}
		pdao.update(vo);
		return "redirect:/";
	}
	
	@RequestMapping("read")
	public String read(String pcode, Model model){
		model.addAttribute("vo", service.read(pcode));
		model.addAttribute("attList", adao.list(pcode));
		model.addAttribute("pageName", "read.jsp");
		return "home";
	}
	
	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public String insertPost(ProductVO vo, MultipartHttpServletRequest multi) throws Exception{
		//��ǥ�̹��� ���ε�
		MultipartFile file = multi.getFile("file");
		String image = System.currentTimeMillis() + "_" + file.getOriginalFilename();
		file.transferTo(new File(path + "/" + image));
		vo.setImage(image);
		
		//�������Է�
		pdao.insert(vo);
		return "redirect:/";
	}
	
	@RequestMapping("/insert")
	public String insert(Model model){
		String maxCode = pdao.maxCode();
		String pcode = "P" + (Integer.parseInt(maxCode.substring(1)) + 1);
		model.addAttribute("pcode", pcode);
		model.addAttribute("pageName", "insert.jsp");
		return "home";
	}
	
	@RequestMapping("/list.json")
	@ResponseBody
	public HashMap<String, Object> list(Criteria cri, String orderType){
		HashMap<String, Object> map = new HashMap<>();
		cri.setPerPageNum(8);
		map.put("cri", cri);
		map.put("list", pdao.list(cri, orderType));
		
		PageMaker pm = new PageMaker();
		pm.setCri(cri);
		pm.setTotalCount(pdao.totCount(cri));
		map.put("pm", pm);
		return map;
	}
	
	// �̹������� �������� ���
	@RequestMapping("/display")
	@ResponseBody
	public ResponseEntity<byte[]> display(String fileName) throws Exception {
		ResponseEntity<byte[]> result = null;
		// display fileName�� �ִ� ���
		if (!fileName.equals("")) {
			File file = new File(path + File.separator + fileName);
			HttpHeaders header = new HttpHeaders();
			header.add("Content-Type", Files.probeContentType(file.toPath()));
			result = new ResponseEntity<>(FileCopyUtils.copyToByteArray(file), header, HttpStatus.OK);
		}
		return result;
	}
}
