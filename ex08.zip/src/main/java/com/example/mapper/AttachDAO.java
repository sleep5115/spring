package com.example.mapper;

import java.util.List;

public interface AttachDAO {
	public List<String> list(String pcode);
	public void insert(String pcode, String image);
	public void delete(String image);
}
