package com.example.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AttachDAOImpl implements AttachDAO{
	
	@Autowired
	SqlSession session;
	
	String namespace="com.example.mapper.AttachMapper";
	
	@Override
	public List<String> list(String pcode) {
		return session.selectList(namespace + ".list", pcode);
	}

	@Override
	public void insert(String pcode, String image) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("pcode", pcode);
		map.put("image", image);
		session.insert(namespace + ".insert", map);
	}

	@Override
	public void delete(String image) {
		session.delete(namespace + ".delete", image);
	}
	
}
