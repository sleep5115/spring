package com.example.mapper;

import java.util.HashMap;
import java.util.List;

import com.example.domain.Criteria;
import com.example.domain.ProductVO;

public interface ProductDAO {
	public List<ProductVO> list(Criteria cri, String orderType);
	public void insert(ProductVO vo);
	public void update(ProductVO vo);
	public void delete(String pcode);
	public ProductVO read(String pcode);
	public String maxCode();
	public int totCount(Criteria cri);
	public void viewcnt(String pcode);
	public List<HashMap<String, Object>> bestProduct();
	public List<HashMap<String, Object>> newProduct();
}
