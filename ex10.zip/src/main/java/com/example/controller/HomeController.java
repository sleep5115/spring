package com.example.controller;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;

import com.example.domain.ProfessorVO;
import com.example.mapper.ProfessorDAO;


@Controller
public class HomeController {
	@Autowired
	ProfessorDAO pdao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model, HttpServletRequest request){
		//��Ű��Ȯ��
		Cookie cookie = WebUtils.getCookie(request, "pcode");
		if(cookie != null){
			String pcode = cookie.getValue();
			request.getSession().setAttribute("pcode", cookie.getValue());
			ProfessorVO vo = pdao.read(pcode);
			request.getSession().setAttribute("pname", vo.getPname());
		}
		model.addAttribute("pageName", "about.jsp");
		return "home";
	}
}
