package com.example.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.WebUtils;

import com.example.domain.ProfessorVO;
import com.example.mapper.ProfessorDAO;

@Controller
public class ProfessorController {
	
	@Autowired
	ProfessorDAO pdao;
	
	@RequestMapping("/login")
	public String login(Model model){
		model.addAttribute("pageName", "login.jsp");
		return "home";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session, HttpServletRequest request, HttpServletResponse response){
		session.invalidate();
		//��Ű������
		Cookie cookie = WebUtils.getCookie(request, "pcode");
		if(cookie != null){
			cookie.setPath("/");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
		}
		return "redirect:/";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	@ResponseBody
	public int loginPost(String pcode, String pass, HttpSession session, boolean isLogin, HttpServletResponse response){
		int result=0;
		ProfessorVO vo = pdao.read(pcode);
		if(vo != null){
			if(pass.equals(vo.getPass())){
				result = 1;
				session.setAttribute("pcode", pcode);
				session.setAttribute("pname", vo.getPname());
				if(isLogin){ //�α��λ��� ����
					Cookie cookie = new Cookie("pcode", pcode);
					cookie.setPath("/");
					cookie.setMaxAge(60 * 60);
					response.addCookie(cookie);
				}
			} else {
				result = 2;
			}
		}
		return result;
	}
}
