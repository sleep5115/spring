package com.example.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.mapper.StudentDAO;

@Controller
public class StudentController {
	@Autowired
	StudentDAO sdao;
	
	@RequestMapping("/stu/list")
	public String list(Model model){
		model.addAttribute("pageName", "slist.jsp");
		return "home";
	}
	
	@RequestMapping("/stu/read")
	public String read(Model model, String scode){
		model.addAttribute("vo", sdao.read(scode));
		model.addAttribute("pageName", "sread.jsp");
		return "home";
	}
	
	@RequestMapping("/students.json")
	@ResponseBody
	public List<HashMap<String, Object>> list(){
		return sdao.list();
	}
}
