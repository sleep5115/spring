package com.example.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.StudentVO;

@Repository
public class StudentDAOImpl implements StudentDAO{
	@Autowired
	SqlSession session;
	
	String namespace="com.example.mapper.StudentMapper";

	@Override
	public List<HashMap<String, Object>> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public StudentVO read(String scode) {
		return session.selectOne(namespace + ".read", scode);
	}
	
}
