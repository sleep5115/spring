package com.example.mapper;

import com.example.domain.ProfessorVO;

public interface ProfessorDAO {
	public ProfessorVO read(String pcode);
}
