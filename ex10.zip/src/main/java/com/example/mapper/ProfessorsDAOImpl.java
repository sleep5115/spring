package com.example.mapper;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.ProfessorVO;

@Repository
public class ProfessorsDAOImpl implements ProfessorDAO{
	@Autowired
	SqlSession session;
	String namespace="com.example.mapper.ProfessorMapper";
	
	@Override
	public ProfessorVO read(String pcode) {
		return session.selectOne(namespace + ".read", pcode);
	}
}
