package com.example.mapper;

import java.util.HashMap;
import java.util.List;

import com.example.domain.StudentVO;

public interface StudentDAO {
	public List<HashMap<String, Object>> list();
	public StudentVO read(String scode);
}
