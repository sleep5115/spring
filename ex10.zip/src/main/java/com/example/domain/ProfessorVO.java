package com.example.domain;

public class ProfessorVO {
	private String pcode;
	private String pname;
	private String pass;
	
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	@Override
	public String toString() {
		return "ProfessorVO [pcode=" + pcode + ", pname=" + pname + ", pass=" + pass + "]";
	}
}
