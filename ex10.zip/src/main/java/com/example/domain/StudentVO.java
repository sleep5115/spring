package com.example.domain;

public class StudentVO extends ProfessorVO{
	private String scode;
	private String dept;
	private String sname;
	
	public String getScode() {
		return scode;
	}
	public void setScode(String scode) {
		this.scode = scode;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	@Override
	public String toString() {
		return "StudentVO [scode=" + scode + ", dept=" + dept + ", sname=" + sname + "]";
	}
}
