package com.example.mapper;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MovieDAOImpl implements MovieDAO{
	@Autowired
	SqlSession session;
	String namespace="com.example.mapper.MovieMapper";
	
	@Override
	public void insert(String title, String image) {
		HashMap<String, Object> map=new HashMap<>();
		map.put("title", title);
		map.put("image", image);
		session.insert(namespace + ".insert", map);
	}
}
