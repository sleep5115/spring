package com.example.mapper;


public interface MovieDAO {
	public void insert(String title, String image);
}
