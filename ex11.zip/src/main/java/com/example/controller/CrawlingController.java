package com.example.controller;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapper.MovieDAO;

@RestController
public class CrawlingController {
	@Autowired
	MovieDAO dao;
	
	@RequestMapping("/cgvmore.json")
	public List<HashMap<String,Object>> cgvMore(){
		List<HashMap<String,Object>> array=new ArrayList<HashMap<String,Object>>();
		try{
			System.setProperty("webdriver.chrome.driver", "c:/chromedriver.exe");
			ChromeOptions options=new ChromeOptions();
			//options.addArguments("headless");
			WebDriver driver=new ChromeDriver(options);
			driver.get("http://www.cgv.co.kr/movies/");
			try{
				Thread.sleep(1000);
			}catch(Exception e){}
			
			WebElement btnMore=driver.findElement(By.className("link-more"));
			btnMore.click();
			try{
				Thread.sleep(1000);
			}catch(Exception e){}
			
			
			List<WebElement> elements=driver.findElements(By.cssSelector(".sect-movie-chart ol li"));
			for(WebElement e:elements){
				HashMap<String, Object> map=new HashMap<String, Object>();
				String title=e.findElement(By.className("title")).getText();
				String image=e.findElement(By.tagName("img")).getAttribute("src");
				String link = e.findElement(By.tagName("a")).getAttribute("href");
				map.put("image", image);
				map.put("title", title);
				map.put("link", link);
				
				//�̹��� Copy (cgv����->��Ĺ����)
				URL url=new URL(image);
				InputStream in = url.openStream();
				String path="c:/zzz/upload";
				String file="/movie/" + System.currentTimeMillis() + ".jpg";
				OutputStream out = new FileOutputStream(path+file);
				FileCopyUtils.copy(in, out);
				
				dao.insert(title, file);
				array.add(map);
			}
			driver.quit();
		}catch(Exception e){
			System.out.println("����:" + e.toString());
		}
		return array;
	}
	
	@RequestMapping("/weather.json")
	public List<HashMap<String,Object>> weacher(){
		List<HashMap<String,Object>> array=new ArrayList<HashMap<String,Object>>();
		try{
			System.setProperty("webdriver.chrome.driver", "c:/chromedriver.exe");
			ChromeOptions options=new ChromeOptions();
			//options.addArguments("headless");
			WebDriver driver=new ChromeDriver(options);
			driver.get("https://www.daum.net/");
			try{
				Thread.sleep(1000);
			}catch(Exception e){}
			
			List<WebElement> elements=driver.findElements(By.cssSelector(".list_weather li"));		
			for(WebElement e:elements){
				HashMap<String, Object> map=new HashMap<String, Object>();
				String part = e.findElement(By.className("txt_part")).getAttribute("textContent");
	            String weather = e.findElement(By.tagName("strong")).getAttribute("textContent");
	            String temper = e.findElement(By.className("txt_temper")).getAttribute("textContent");
				map.put("part", part);
				map.put("weathr", weather);
				map.put("temper", temper);
				array.add(map);
			}
			
			driver.quit();
		}catch(Exception e){
			System.out.println("����:" + e.toString());
		}
		return array;
	}
	
	@RequestMapping("/cgv.json")
	public List<HashMap<String,Object>> cgv(){
		List<HashMap<String,Object>> array=new ArrayList<HashMap<String,Object>>();
		try{
			Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/").get();
			Elements elements=doc.select(".sect-movie-chart ol");
			//System.out.println(elements);
			for(Element e:elements.select("li")){
				HashMap<String,Object> map=new HashMap<String,Object>();
				String rank=e.select(".rank").text();
				String title=e.select(".title").text();
				String date=e.select(".txt-info strong").text();
				String image=e.select("img").attr("src");
				if(!rank.equals("")) {
					map.put("rank", rank);
					map.put("title", title);
					map.put("date", date);
					map.put("image", image);
					array.add(map);
				}
			}
		}catch(Exception e){
			System.out.println("����:" + e.toString());
		}
		return array;
	}
}
