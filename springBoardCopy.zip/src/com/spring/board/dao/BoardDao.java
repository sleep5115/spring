package com.spring.board.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.spring.board.vo.BoardVo;
import com.spring.board.vo.ComCodeVo;
import com.spring.board.vo.JoinVo;
import com.spring.board.vo.PageVo;

public interface BoardDao {

	public String selectTest() throws Exception;

//	public List<BoardVo> selectBoardList(PageVo pageVo, List<String> codeId) throws Exception;

	public List<BoardVo> selectBoardList(PageVo pageVo, String[] codeId) throws Exception;

	public BoardVo selectBoard(BoardVo boardVo) throws Exception;

	public int selectBoardCnt() throws Exception;

	public int boardInsert(BoardVo boardVo) throws Exception;
	
	public int boardUpdate(BoardVo boardVo) throws Exception;
	
	public int boardDelete(int boardNum) throws Exception;
	
	public List<ComCodeVo> comCodeType() throws Exception;
	
	public List<JoinVo> joinNumType() throws Exception;
	
	public int boardJoin(JoinVo joinVo) throws Exception;
	
	public int idCheck(JoinVo joinVo) throws Exception;
	
	public JoinVo login(JoinVo joinVo) throws Exception;
	
}
