package com.spring.board.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.board.HomeController;
import com.spring.board.service.boardService;
import com.spring.board.vo.BoardVo;
import com.spring.board.vo.ComCodeVo;
import com.spring.board.vo.JoinVo;
import com.spring.board.vo.PageVo;
import com.spring.common.CommonUtil;

import net.sf.json.JSONArray;
import oracle.net.ano.Service;

@Controller
public class BoardController {
	
	@Autowired 
	boardService boardService;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/board/boardList.do", method = RequestMethod.GET)
	public String boardList(Locale locale, Model model, PageVo pageVo
//			,ArrayList<String> codeId 
//			,String jsonCodeId
			,HttpServletRequest request
			,String[] codeId
			) throws Exception{
		
		System.out.println("/board/boardList.do");
		
		System.out.println("boardList.do���� codeId : " + codeId);
		
		List<BoardVo> boardList = new ArrayList<BoardVo>();
		List<ComCodeVo> comCodeType = new ArrayList<ComCodeVo>();
//		JSONArray codeId = JSONArray.fromObject(jsonCodeId);
//		String[] codeId;
//		codeId = request.getParameterValues("codeId"); // checkbox �� ��������
		
		
//		HashMap<String, Object> checked = new HashMap<String, Object>();
//		checked.put("codeIdArr", pageVo.getCodeIdArr());
		int page = 1;
		int totalCnt = 0;
		
		if(pageVo.getPageNo() == 0){
			pageVo.setPageNo(page);;
		}
//		if(checked != null) {
//			for (int i = 0; i < checked.length; i++) {
//				System.out.println("checked : " + checked[i]);
//			}
//		}
		
		
		boardList = boardService.SelectBoardList(pageVo, codeId);
		comCodeType = boardService.comCodeType();
		totalCnt = boardService.selectBoardCnt();
		
		System.out.println(boardList);
		
		model.addAttribute("boardList", boardList);
		model.addAttribute("comCodeType", comCodeType);
		model.addAttribute("totalCnt", totalCnt);
		model.addAttribute("pageNo", page);
		
		return "board/boardList";
	}
	
	@RequestMapping(value = "/board/boardTest.do", method=RequestMethod.POST, produces="application/json; charset=UTF-8")
	@ResponseBody
	public String boardTest(Model model, PageVo pageVo, @RequestParam String[] codeId) throws Exception {
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		List<BoardVo> boardList = new ArrayList<BoardVo>();
		List<ComCodeVo> comCodeType = new ArrayList<ComCodeVo>();
		
		System.out.println("/board/boardList.do");
		System.out.println("boardTest.do���� codeId : " + codeId);
		
		int page = 1;
		int totalCnt = 0;
		
		if(pageVo.getPageNo() == 0){
			pageVo.setPageNo(page);;
		}
		
		boardList = boardService.SelectBoardList(pageVo, codeId);
		comCodeType = boardService.comCodeType();
		totalCnt = boardService.selectBoardCnt();
		
		map.put("boardList", boardList);
//		map.put("comCodeType", comCodeType);
//		map.put("totalCnt", totalCnt);
//		map.put("pageNo", page);
		
		System.out.println("test.do���� boardList �� : " + map );
		String jsonMap = CommonUtil.getJsonCallBackString(" ", map);
		
		System.out.println("jsonMap : " + jsonMap);
		return jsonMap;
	}
	
	@RequestMapping(value = "/board/{codeName}/{boardNum}/boardView.do", method = RequestMethod.GET)
	public String boardView(Locale locale, Model model
			,@PathVariable("codeName")String codeName
			,@PathVariable("boardNum")int boardNum) throws Exception{
		
		BoardVo boardVo = new BoardVo();
		
		
		boardVo = boardService.selectBoard(codeName,boardNum);
		
		model.addAttribute("codeName", codeName);
		model.addAttribute("boardNum", boardNum);
		model.addAttribute("board", boardVo);
		
		return "board/boardView";
	}
	
	@RequestMapping(value = "/board/boardWrite.do", method = RequestMethod.GET)
	public String boardWrite(Locale locale, Model model) throws Exception{
		
		List<BoardVo> boardList = new ArrayList<BoardVo>();
		List<ComCodeVo> comCodeType = new ArrayList<ComCodeVo>();
		
		comCodeType = boardService.comCodeType();
		
		model.addAttribute("boardList", boardList);
		model.addAttribute("comCodeType", comCodeType);
		
		return "board/boardWrite";
	}
	
	@RequestMapping(value = "/board/boardWriteAction.do", method=RequestMethod.POST)
	@ResponseBody
	public String boardWriteAction(Locale locale, BoardVo boardVo) throws Exception{
		
		HashMap<String, String> result = new HashMap<String, String>();
		CommonUtil commonUtil = new CommonUtil();
		
		List<BoardVo> list = boardVo.getList();
		
		int resultCnt = 0;
		
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getBoardTitle() == null || 
					list.get(i).getBoardTitle().equals("")){
					continue;
				}
			resultCnt = boardService.boardInsert(list.get(i));
			
		}
		
		result.put("success", (resultCnt > 0)?"Y":"N");
		String callbackMsg = commonUtil.getJsonCallBackString(" ",result);
		
		System.out.println("callbackMsg::"+callbackMsg);
		
		return callbackMsg;
	}
	
	
	
	@RequestMapping(value = "/board/{boardType}/{boardNum}/boardUpdate.do", method = RequestMethod.GET)
	public String boardUpdate(Locale locale, Model model
			,@PathVariable("boardNum")int boardNum
			,@PathVariable("boardType")String boardType) throws Exception{
		BoardVo boardVo = new BoardVo();
		List<ComCodeVo> comCodeType = new ArrayList<ComCodeVo>();
		comCodeType = boardService.comCodeType();
		
		boardVo = boardService.selectBoard(boardType,boardNum);
		model.addAttribute("boardType", boardType);
		model.addAttribute("boardNum", boardNum);
		model.addAttribute("board", boardVo);
		model.addAttribute("comCodeType", comCodeType);
		return "board/boardUpdate";
	}
	
	@RequestMapping(value = "/board/boardUpdateAction.do", method = RequestMethod.POST)
	@ResponseBody
	public String boardUpdateAction(Locale locale,BoardVo boardVo) throws Exception{
		
		HashMap<String, String> result = new HashMap<String, String>();
		CommonUtil commonUtil = new CommonUtil();
		
		int resultCnt = boardService.boardUpdate(boardVo);
		
		result.put("success", (resultCnt > 0)?"Y":"N");
		String callbackMsg = commonUtil.getJsonCallBackString(" ",result);
		
		System.out.println("callbackMsg::"+callbackMsg);
		
		return callbackMsg;
	}
	
	@RequestMapping(value = "/board/boardDeleteAction.do", method = RequestMethod.POST)
	@ResponseBody
	public String boardDeleteAction(Locale locale,int boardNum) throws Exception{
		
		HashMap<String, String> result = new HashMap<String, String>();
		CommonUtil commonUtil = new CommonUtil();
		
		int resultCnt = boardService.boardDelete(boardNum);
		
		result.put("success", (resultCnt > 0)?"Y":"N");
		String callbackMsg = commonUtil.getJsonCallBackString(" ",result);
		
		System.out.println("callbackMsg::"+callbackMsg);
		
		return callbackMsg;
	}
	
	@RequestMapping(value = "/board/boardJoin.do", method = RequestMethod.GET)
	public String boardJoin(Locale locale, Model model) throws Exception{
		
		List<JoinVo> joinNumType = new ArrayList<JoinVo>();

		joinNumType = boardService.joinNumType();
		model.addAttribute("joinNumType", joinNumType);
		return "board/boardJoin";
	}
	
	@RequestMapping(value = "/board/boardJoinAction.do", method=RequestMethod.POST)
	@ResponseBody
	public String boarJoinAction(Locale locale, JoinVo joinVo) throws Exception{
		
		HashMap<String, String> result = new HashMap<String, String>();
		CommonUtil commonUtil = new CommonUtil();
		
		
		int resultCnt = boardService.boardJoin(joinVo);
		
		result.put("success", (resultCnt > 0)?"Y":"N");
		String callbackMsg = commonUtil.getJsonCallBackString(" ",result);
		
		System.out.println("callbackMsg::"+callbackMsg);
		
		return callbackMsg;
	}
	
	@RequestMapping(value = "/board/idCheck.do", method=RequestMethod.POST)
	@ResponseBody
	public int idCheck(JoinVo joinVo) throws Exception {
		int result = boardService.idCheck(joinVo);
		return result;
	}
	
	@RequestMapping(value = "/board/boardLogin.do", method=RequestMethod.GET)
	public String boardLogin() throws Exception {
		
		return "board/boardLogin";
	}
	
	@RequestMapping(value = "/board/boardLoginAction.do", method=RequestMethod.POST)
	public String boardLoginAction(JoinVo joinVo, HttpServletRequest req, RedirectAttributes rttr) throws Exception {
		
		HttpSession session = req.getSession();
		JoinVo login = boardService.login(joinVo);
		System.out.println(login);
		if(login != null) {
			rttr.addFlashAttribute("msg", "");
			session.setAttribute("user", login);
			return "redirect:/board/boardList.do";
		}
		else {
			session.setAttribute("user", null);
			rttr.addFlashAttribute("msg", "����");
			return "redirect:/board/boardLogin.do";
		}
	}
	
	@RequestMapping(value = "/board/boardLogout.do", method = RequestMethod.GET)
	public String logout(HttpSession session) throws Exception{
		
		session.invalidate();
		
		return "redirect:/board/boardList.do";
	}
}
