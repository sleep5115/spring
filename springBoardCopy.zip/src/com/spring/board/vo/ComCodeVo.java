package com.spring.board.vo;

import java.util.List;

public class ComCodeVo {

	private String codeType;
	private String codeId;
	private String codeName;
	private String creator;
	private String createTime;
	private String modifier;
	private String modifiedTime;
	
	private List<ComCodeVo> codeList;
	
	
	
	public String getCodeType() {
		return codeType;
	}
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}
	public String getCodeId() {
		return codeId;
	}
	public void setCodeId(String codeId) {
		this.codeId = codeId;
	}
	public String getCodeName() {
		return codeName;
	}
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public List<ComCodeVo> getCodeList() {
		return codeList;
	}
	public void setCodeList(List<ComCodeVo> codeList) {
		this.codeList = codeList;
	}
	
	
}