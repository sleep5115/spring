package com.example.controller;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.domain.Criteria;
import com.example.mapper.BoardMapper;
import com.example.mapper.MysqlMapper;
import com.example.mapper.ReplyMapper;

@RunWith(SpringJUnit4ClassRunner.class) //���� SpringJUnit4ClassRunner.class import�Ѵ�.
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
public class MysqlTest {
	@Autowired
	private MysqlMapper mapper;

	@Test
	public void getTime() {
		mapper.getTime();
	}
	
	@Autowired
	ReplyMapper rmapper;
	
	@Test
	public void list() {
		Criteria cri = new Criteria();
		HashMap<String, Object> map = new HashMap<>();
		map.put("bno", 249);
		map.put("cri", cri);
		rmapper.list(map);
	}
	
	@Test
	public void total() {
		rmapper.totalCount(252);
	}
}
