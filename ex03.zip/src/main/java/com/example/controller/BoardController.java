package com.example.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.mapper.BoardMapper;
import com.example.service.BoardService;

@Controller
@RequestMapping("/board")
public class BoardController {
	@Autowired
	BoardMapper mapper;
	
	@Autowired
	BoardService service;
	
	@RequestMapping("/list.json")
	@ResponseBody
	public HashMap<String, Object> list(Criteria cri){
		HashMap<String, Object> map = new HashMap<String, Object>();
		cri.setPerPageNum(5);
		map.put("list", mapper.list(cri));
		map.put("cri", cri);
		
		PageMaker pm = new PageMaker();
		pm.setDisplayPageNum(5);
		pm.setCri(cri);
		pm.setTotalCount(mapper.totalCount(cri));
		map.put("pm", pm);
		return map;
	}
	
	@RequestMapping("/list")
	public String listGet(Model model) {
		model.addAttribute("pageName", "board/list.jsp");
		return "home";
	}
	
	@RequestMapping("/read")
	public String readGet(Model model, int bno) {
		model.addAttribute("vo", service.read(bno));
		model.addAttribute("pageName", "board/read.jsp");
		return "home";
	}
}
