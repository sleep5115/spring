package com.example.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.domain.ReplyVO;
import com.example.mapper.ReplyMapper;

@RestController
@RequestMapping("/reply")
public class ReplyController {
	@Autowired
	ReplyMapper mapper;
	
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public void insert(ReplyVO vo) {
		mapper.insert(vo);
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public void delete(int rno) {
		mapper.delete(rno);
	}
	
	@RequestMapping("/list.json")
	public HashMap<String, Object> list(Criteria cri, int bno) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		cri.setPerPageNum(5);
		
		HashMap<String, Object> m = new HashMap<String, Object>();
		m.put("cri", cri);
		m.put("bno", bno);
		
		map.put("list", mapper.list(m));
		map.put("cri", cri);
		
		PageMaker pm = new PageMaker();
		pm.setDisplayPageNum(5);
		pm.setCri(cri);
		pm.setTotalCount(mapper.totalCount(bno));
		map.put("pm", pm);
		return map;
	}
}
