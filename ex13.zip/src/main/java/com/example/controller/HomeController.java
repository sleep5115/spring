package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.UserVO;
import com.example.mapper.NoticeDAO;
import com.example.mapper.UserDAO;


@Controller
public class HomeController {
	@Autowired
	UserDAO dao;
	
	@Autowired
	NoticeDAO ndao;
	
	@RequestMapping(value = "/chat", method = RequestMethod.GET)
	public String chat() {
		return "chat";
	}
	
	@RequestMapping(value = "/notice", method = RequestMethod.GET)
	public String notice(Model model, HttpSession session) {
		String uid=(String)session.getAttribute("uid");
		ndao.noticeReadDate(uid);
		session.setAttribute("count", ndao.noticeUnreadCount(uid));
		model.addAttribute("pageName", "notice.jsp");
		return "home";
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("pageName", "about.jsp");
		return "home";
	}
	
	@RequestMapping("/login")
	public String login(Model model){
		model.addAttribute("pageName", "login.jsp");
		return "home";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	@ResponseBody
	public int loginPost(String uid, String upass, HttpSession session){
		int result=0;
		UserVO vo=dao.login(uid);
		if(vo!=null){
			if(vo.getUpass().equals(upass)){
				session.setAttribute("uid", uid);
				session.setAttribute("count", ndao.noticeUnreadCount(uid));
				result=1;
			}else{
				result=2;
			}
		}
		return result;
	}
}





