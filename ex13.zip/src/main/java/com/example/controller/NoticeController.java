package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.NoticeVO;
import com.example.mapper.NoticeDAO;

@RestController
public class NoticeController {
	@Autowired
	NoticeDAO dao;
	
	@RequestMapping("/notice.json")
	public List<NoticeVO> noticeJSON(String uid){
		dao.noticeReadDate(uid);
		return dao.list();
	}
	
	@RequestMapping(value="/notice/insert", method=RequestMethod.POST)
	public void insert(NoticeVO vo){
		dao.insert(vo);
	}
	
	@RequestMapping(value="/notice/delete", method=RequestMethod.POST)
	public void delete(int id){
		dao.delete(id);
	}
	
	@RequestMapping(value="/notice/unreadCount")
	public int unReadCount(String uid){
		return dao.noticeUnreadCount(uid);
	}
}
